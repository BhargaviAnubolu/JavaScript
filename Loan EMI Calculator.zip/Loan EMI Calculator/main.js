function setInitialValue() {
  console.log('setInitialValue');
  ComputeResults();
}

// Calculating the Home Loan 
function getLoanAmount() {
  return document.getElementById("amount").value;
}
function getLoanInterestRate() {
  return document.getElementById("interest").value;

}
function getLoanTenure() {
  return document.getElementById("years").value;
}

// complete   monthlyEMI formula
// P x R x (1+R)^N / [(1+R)^N-1] 
function getMonthlyEMI() {
  const PrincipleAmount = getLoanAmount();
  const MonthlyInterestRate = getMonthlyInterestRate(getLoanInterestRate());
  const TenureYearly = getLoanTenure() * 12;
  const EMI = PrincipleAmount * MonthlyInterestRate *
    (Math.pow(1 + MonthlyInterestRate, TenureYearly) /
      (Math.pow(1 + MonthlyInterestRate, TenureYearly) - 1));
  return EMI;

}
//Monthly Loan Interest Rate formula
function getMonthlyInterestRate(LoanInterestRate) {
  return LoanInterestRate / 12 / 100;

}
// Loan Tenure month formula
function getTenureMonth() {
  return getLoanTenure() * 12;
}
// Calculated Results
// calling the table function to get result
function ComputeResults() {
  console.log('ComputeResults');
  
  const TotalInterest = (getMonthlyEMI() * getLoanTenure() * 12 - getLoanAmount()).toFixed();
  document.getElementById("totalInterest").innerHTML = TotalInterest;

  const TotalPayment = (getMonthlyEMI() * getLoanTenure() * 12).toFixed();
  document.getElementById("totalPayment").innerHTML = TotalPayment;

  const MonthlyPayment = getMonthlyEMI().toFixed();
  document.getElementById("monthlyPayment").innerHTML = MonthlyPayment;
  Table();
}

//Create an Array 
//create an object push the object to array
//return array outside of the loop
function generateArray(MonthlyEMI, TenureInMonth, LoanAmount, MonthlyInterest) {
  
  const data_array = [];
  let OutstandingBalance = LoanAmount;
  for (let i = 0; i < TenureInMonth; i++) {

    console.log(typeof (MonthlyEMI));
    
    const my_object = {
      "Month": i+1,
      "OpeningBalance": OutstandingBalance,
      "MonthlyEMI": (+MonthlyEMI).toFixed(),
      "PrinciplePaid": (+MonthlyEMI - (+OutstandingBalance * MonthlyInterest)).toFixed(),
      "InterestPaid": (+OutstandingBalance * MonthlyInterest).toFixed(),
      "ClosingBalance": OutstandingBalance-MonthlyEMI
    };
    my_object.OutstandingBalance = +OutstandingBalance - my_object.PrinciplePaid;
    OutstandingBalance = (my_object.OutstandingBalance);
    data_array.push(my_object);
  }
  console.table(data_array);
  return data_array;
}

// create table
function Table() {
  const MonthlyPayment = getMonthlyEMI().toFixed();
  const TenureInMonth = getTenureMonth();
  const LoanAmount = getLoanAmount();
  const MonthlyInterest = getMonthlyInterestRate(getLoanInterestRate());
  let a = generateArray(MonthlyPayment, TenureInMonth, LoanAmount, MonthlyInterest);
  console.log("a:",a);
  let table="<table>";
  table+="<tr>";
  table+="<th>"+"Month "+"</th>";
  table+="<th>"+"OpeningBalance "+"</th>";
  table+="<th>"+"MonthlyEMI "+"</th>";
  table+="<th>"+"PriciplePaid "+"</th>";
  table+="<th>"+"InterestPaid "+"</th>";
  table+="<th>"+"ClosingBalance "+"</th>";
  table+="<th>"+"OutstandibgBalance "+"</th>";
 
  table+="</tr>";
  table+="<tr>";
  for(var i=0;i<a.length;i++){
    table+="<tr>";
for(j in a[i]){
    table+="<td>"+a[i][j]+"</td>";
}
table+="</tr>";
}
table+="</table>";
document.getElementById("fetch").innerHTML=table;
}
